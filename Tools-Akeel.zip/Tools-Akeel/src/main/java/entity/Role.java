package entity;

public enum Role {
	CUSTOMER, OWNER, RUNNER
}
