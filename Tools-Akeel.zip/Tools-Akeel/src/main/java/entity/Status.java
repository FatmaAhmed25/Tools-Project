package entity;

public enum Status {
	PREPARING, DELIVERED , CANCELED
}