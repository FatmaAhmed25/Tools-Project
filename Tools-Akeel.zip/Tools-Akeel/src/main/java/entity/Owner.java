package entity;

public class Owner {

}
