package entity;

public class Customer {

}
